module.exports = {
    name: 'podnara',
    description: 'Mostra informações sobre o podcast Podnara',
    async execute(interaction) {
        await interaction.reply({
            content: `🎙️ **Podnara**\nO podcast da Arthur e da sua namorada 😄\n\n📌 Siga e acompanhe:\n🔗 [Ouça aqui](https://seu-link-do-podcast.com)\n\n💬 "Histórias, risadas e boas conversas sempre!"`,
            ephemeral: false
        });
    }
};